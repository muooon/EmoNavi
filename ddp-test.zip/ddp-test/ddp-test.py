# [1] ライブラリインポート
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import json
import os
import time
import threading
import queue
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Subset
from torch.optim import AdamW
import random # ランダムな遅延用

# EmoNaviクラス定義（提供されたコードをそのまま貼り付けます）
class EmoNavi(torch.optim.Optimizer):
    # クラス定義＆初期化
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999),
                 eps=1e-8, weight_decay=0.01):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)
        self.should_stop = False # EmoNAVIの自動停止フラグ

    # 感情EMA更新(緊張と安静)
    def _update_ema(self, state, loss_val):
        ema = state.setdefault('ema', {})
        ema['short'] = 0.3 * loss_val + 0.7 * ema.get('short', loss_val)
        ema['long']  = 0.01 * loss_val + 0.99 * ema.get('long', loss_val)
        return ema

    # 感情スカラー値生成(EMA差分、滑らかな非線形スカラー、tanh 5 * diff で鋭敏さ強調)
    def _compute_scalar(self, ema):
        diff = ema['short'] - ema['long']
        return math.tanh(5 * diff)

    # Shadow混合比率(> 0.6：70〜90%、 < 0.6：10%、 > 0.3：30%、 平時：0%)
    def _decide_ratio(self, scalar):
        if scalar > 0.6:
            return 0.7 + 0.2 * scalar
        elif scalar < -0.6:
            return 0.1
        elif abs(scalar) > 0.3:
            return 0.3
        return 0.0

    # 損失取得(損失値 loss_val を数値化、感情判定に使用、存在しないパラメータ(更新不要)はスキップ)
    @torch.no_grad()
    def step(self, closure=None):
        loss = closure() if closure is not None else None # closure()を呼び出す
        loss_val = loss.item() if loss is not None else 0.0

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                state = self.state[p]

                # EMA更新・スカラー生成(EMA差分からスカラーを生成しスパイク比率を決定)
                ema = self._update_ema(state, loss_val)
                scalar = self._compute_scalar(ema)
                ratio = self._decide_ratio(scalar)

                # shadow_param：必要時のみ更新(スパイク部分に現在値を5%ずつ追従させる動的履歴)
                if ratio > 0:
                    if 'shadow' not in state:
                        state['shadow'] = p.data.clone()
                    else:
                        p.data.mul_(1 - ratio).add_(state['shadow'], alpha=ratio)
                        state['shadow'].lerp_(p.data, 0.05)
                 
                # 1次・2次モーメントを使った勾配補正(decoupled weight decay 構造に近い)
                exp_avg = state.setdefault('exp_avg', torch.zeros_like(p.data))
                exp_avg_sq = state.setdefault('exp_avg_sq', torch.zeros_like(p.data))
                beta1, beta2 = group['betas']
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)
                denom = exp_avg_sq.sqrt().add_(group['eps'])

                step_size = group['lr']
                if group['weight_decay']:
                    p.data.add_(p.data, alpha=-group['weight_decay'] * step_size)
                p.data.addcdiv_(exp_avg, denom, value=-step_size)

            # 感情機構の発火が収まり"十分に安定"していることを外部伝達できる(自動停止ロジックではない)
            # Early Stop用 scalar 記録(バッファ共通で管理/最大32件保持/動静評価)
            hist = self.state.setdefault('scalar_hist', [])
            hist.append(scalar)
            if len(hist) > 32:
                hist.pop(0)

            # Early Stop判断(静けさの合図)
            if len(self.state['scalar_hist']) >= 32:
                buf = self.state['scalar_hist']
                avg_abs = sum(abs(s) for s in buf) / len(buf)
                std = sum((s - sum(buf)/len(buf))**2 for s in buf) / len(buf)
                if avg_abs < 0.05 and std < 0.005: # EmoNAVIの停止条件
                    self.should_stop = True # 💡 外部からこれを見て判断可

        return loss

# [2] SmallCNN モデル定義
class SmallCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(8, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout(0.3)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(16 * 7 * 7, 64),
            nn.ReLU(),
            nn.Linear(64, 2) # MNIST 0/1分類のため出力は2
        )

    def forward(self, x):
        x = self.features(x)
        return self.classifier(x)

# [3] グローバルモデルと更新キュー (共有リソース)
global_model = SmallCNN()
model_updates_queue = queue.Queue()
server_events_log = [] # サーバーのイベントを記録するリスト

# [4] データローダー（MNIST、ノード分割）
# 各ワーカーに割り当てるデータ量を定義
CLIENT_DATA_SIZES = {
    'A': 1300,  # DDP-Worker-A
    'B': 1200, # DDP-Worker-B (より多くのデータを持つことで、同期の律速効果を強調)
    'C': 1300, # EmoNAVI-Worker-C
    'D': 1600  # EmoNAVI-Worker-D (より多くのデータでもEmoNAVIが自律停止することを示す)
}

def get_image_dataloader(node_id, batch_size=32):
    transform = transforms.Compose([transforms.ToTensor()])
    mnist = datasets.MNIST(root='./data', train=True, download=True, transform=transform)

    if node_id == 'A' or node_id == 'C': # '0'に偏らせる
        indices = [i for i, (_, y) in enumerate(mnist) if y == 0]
    elif node_id == 'B' or node_id == 'D': # '1'に偏らせる
        indices = [i for i, (_, y) in enumerate(mnist) if y == 1]
    else:
        raise ValueError(f"Unknown node_id: {node_id}")

    subset = Subset(mnist, indices[:CLIENT_DATA_SIZES[node_id]])
    return DataLoader(subset, batch_size=batch_size, shuffle=True)

def get_dataloader(node_id):
    return get_image_dataloader(node_id)

# ---

# [5a] DDPシミュレーションワーカー (AdamW使用) の修正
def ddp_simulated_worker(worker_id, global_model_ref, data_loader, barrier, update_queue, max_epochs, device='cuda'):
    local_model = SmallCNN().to(device)
    local_model.load_state_dict(global_model_ref.state_dict()) 
    optimizer = AdamW(local_model.parameters(), lr=1e-3, weight_decay=1e-3)
    criterion = nn.CrossEntropyLoss()

    print(f"[DDP-Worker-{worker_id}] 学習開始 (AdamW, 同期モード)")
    start_time = time.time()
    
    step_logs = [] 
    
    for epoch in range(max_epochs):
        for batch_idx, (x, y) in enumerate(data_loader):
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = local_model(x)
            loss = criterion(out, y)
            loss.backward()

            # ここで勾配同期をシミュレート
            barrier_wait_start = time.time()
            try:
                # タイムアウトを設定して、デッドロックを防ぐ/特定しやすくする
                barrier.wait(timeout=60) # 60秒待機。長すぎる場合は調整
            except threading.BrokenBarrierError:
                # バリアが壊れた場合 (例: 他のスレッドが終了したなど)
                print(f"[DDP-Worker-{worker_id}] WARNING: バリアが壊れています。他のワーカーが異常終了した可能性。")
                break # ループを抜けて終了
            barrier_wait_duration = time.time() - barrier_wait_start
            
            optimizer.step()

            current_step = epoch * len(data_loader) + batch_idx
            step_logs.append({
                "step": current_step,
                "epoch": epoch,
                "loss": loss.item(),
                "barrier_wait_time": barrier_wait_duration 
            })
            
            if current_step % 500 == 0 or current_step == 0: 
                 print(f"[DDP-Worker-{worker_id}] Epoch: {epoch+1}/{max_epochs}, Step: {current_step}, Loss: {loss.item():.4f}, Sync_Wait: {barrier_wait_duration:.4f}s")
        else: # for-else: forループがbreakで抜けない場合に実行
            continue # 次のエポックへ
        break # forループがbreakで抜けた場合（バリアエラーなど）、外側のepochループも抜ける

    # ここに到達したら学習が終了している
    end_time = time.time()
    duration = end_time - start_time
    print(f"[DDP-Worker-{worker_id}] 学習完了 (AdamW, Max Epochs {max_epochs}到達/エラー終了, 時間: {duration:.2f}秒)。モデル更新をサーバーに送信中...")
    
    # 完了後、更新をキューに送信
    update_queue.put({
        'worker_id': f"DDP-Worker-{worker_id}",
        'state_dict': local_model.state_dict(),
        'data_size': CLIENT_DATA_SIZES[worker_id] 
    })

    # ログ保存 (以前のコードと同じ)
    os.makedirs("logs", exist_ok=True)
    summary_log = {
        "node": f"DDP-Worker-{worker_id}",
        "optimizer_type": "adamw_ddp_sim",
        "final_epoch": epoch, # 実際に完了したエポック
        "total_steps": len(step_logs),
        "final_loss": loss.item(),
        "local_training_duration_seconds": duration,
        "stopped_by_emonavi_flag": False, 
        "local_training_start_timestamp": start_time,
        "local_training_end_timestamp": end_time,
        "update_sent_timestamp": time.time()
    }
    with open(f"logs/node_DDP-Worker-{worker_id}_summary.json", "w") as f:
        json.dump(summary_log, f, indent=2)
    with open(f"logs/node_DDP-Worker-{worker_id}_steps.json", "w") as f:
        json.dump(step_logs, f, indent=2)

    print(f"[DDP-Worker-{worker_id}] モデル更新送信完了。")

# [5b] EmoNAVIワーカー (非同期・自律動作)
def emonavi_worker(worker_id, global_model_ref, data_loader, update_queue, max_epochs_fallback, device='cuda'):
    local_model = SmallCNN().to(device)
    local_model.load_state_dict(global_model_ref.state_dict())
    optimizer = EmoNavi(local_model.parameters(), lr=1e-3)
    criterion = nn.CrossEntropyLoss()

    print(f"[EmoNAVI-Worker-{worker_id}] 学習開始 (EmoNAVI, 非同期・自律モード)")
    start_time = time.time()

    # EmoNAVIの早期停止基準
    STOP_THRESHOLD = 0.0001
    STABILITY_WINDOW = 50 
    
    scalar_hist = []
    step_logs = []
    
    current_epoch = 0
    local_steps = 0
    
    stopped_by_emonavi = False
    
    while current_epoch < max_epochs_fallback: 
        for batch_idx, (x, y) in enumerate(data_loader):
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = local_model(x)
            loss = criterion(out, y)
            loss.backward()
            
            optimizer.step(closure=lambda: loss) # closureにlambda関数を渡す
            
            # EmoNAVIのscalar値を記録
            scalar_hist_full = optimizer.state.get('scalar_hist', [])
            scalar = scalar_hist_full[-1] if scalar_hist_full else 0.0 # scalar_hist_fullが空の場合の対処
            scalar_hist.append(scalar)

            local_steps += 1
            
            current_step = current_epoch * len(data_loader) + batch_idx
            step_logs.append({
                "step": current_step,
                "epoch": current_epoch,
                "loss": loss.item(),
                "scalar": round(scalar, 8)
            })

            # EmoNAVIのshould_stopフラグをチェックして自律的に学習停止を判断
            if optimizer.should_stop:
                print(f"[EmoNAVI-Worker-{worker_id}] EmoNAVIが学習の安定を検出しました (scalar: {scalar:.6f})。ローカル学習を終了します。")
                stopped_by_emonavi = True
                break # ローカルのデータセットをすべて見ることなく学習を早期終了
            
            if current_step % 500 == 0 or current_step == 0:
                 print(f"[EmoNAVI-Worker-{worker_id}] Epoch: {current_epoch+1}/{max_epochs_fallback}, Step: {current_step}, Loss: {loss.item():.4f}, Scalar: {scalar:.6f}")
        
        current_epoch += 1
        
        # 早期停止した場合、外側のループも抜ける
        if stopped_by_emonavi:
            break
        
        # 最大エポック数に達した場合 (EmoNAVIが自律停止しなかった場合の安全弁)
        if current_epoch >= max_epochs_fallback and not stopped_by_emonavi:
             print(f"[EmoNAVI-Worker-{worker_id}] 最大フォールバックエポック数 ({max_epochs_fallback}) に達しました。ローカル学習を終了します。")
             break

    end_time = time.time()
    duration = end_time - start_time
    print(f"[EmoNAVI-Worker-{worker_id}] 学習完了 (EmoNAVI, 最終エポック: {current_epoch-1}, 合計ステップ: {local_steps}, 時間: {duration:.2f}秒)。モデル更新をサーバーに送信中...")
    
    # 完了後、更新をキューに送信
    update_queue.put({
        'worker_id': f"EmoNAVI-Worker-{worker_id}",
        'state_dict': local_model.state_dict(),
        'data_size': CLIENT_DATA_SIZES[worker_id]
    })

    # ログ保存
    os.makedirs("logs", exist_ok=True)
    # scalar_hist が空の場合に備える
    avg_abs_scalar = sum(map(abs, scalar_hist)) / len(scalar_hist) if scalar_hist else "N/A"

    summary_log = {
        "node": f"EmoNAVI-Worker-{worker_id}",
        "optimizer_type": "emonavi_async",
        "final_epoch": current_epoch - 1,
        "total_steps": local_steps,
        "final_loss": loss.item() if hasattr(loss, 'item') else loss, # lossがtensorでない場合の対処
        "scalar_avg_abs": avg_abs_scalar,
        "local_training_duration_seconds": duration,
        "stopped_by_emonavi_flag": stopped_by_emonavi,
        "local_training_start_timestamp": start_time,
        "local_training_end_timestamp": end_time,
        "update_sent_timestamp": time.time()
    }
    with open(f"logs/node_EmoNAVI-Worker-{worker_id}_summary.json", "w") as f:
        json.dump(summary_log, f, indent=2)
    with open(f"logs/node_EmoNAVI-Worker-{worker_id}_steps.json", "w") as f:
        json.dump(step_logs, f, indent=2)

    print(f"[EmoNAVI-Worker-{worker_id}] モデル更新送信完了。")

# [6] 中央サーバーの修正箇所

def central_server(merge_interval=5, device='cuda'):
    global global_model
    global server_events_log 
    
    os.makedirs("saved_models", exist_ok=True)
    torch.save(global_model.state_dict(), "saved_models/global_model_initial.pth")
    
    print("\n=== 中央サーバー開始 ===")
    print(f"モデル集約インターバル: {merge_interval}秒")

    updated_models_count = 0
    
    while True:
        try:
            get_start_time = time.time()
            update_info = model_updates_queue.get(timeout=merge_interval)
            get_end_time = time.time()
            
            worker_id_full = update_info['worker_id'] 
            client_state_dict = update_info['state_dict']
            client_data_size = update_info['data_size']
            
            print(f"[サーバー] ワーカー {worker_id_full} からの更新を受信しました。")
            
            # サーバーイベントログに「受信」を記録 (ここを修正)
            server_events_log.append({
                "time": get_end_time, # ここを 'time' に変更
                "event_type": "server_received_update",
                "worker_id": worker_id_full,
                "details": "更新を受信"
            })

            current_global_state = global_model.state_dict()
            
            if updated_models_count == 0: 
                for key in current_global_state.keys():
                    current_global_state[key] = client_state_dict[key].float()
            else:
                for key in current_global_state.keys():
                    current_global_state[key] = (current_global_state[key] * updated_models_count + client_state_dict[key].float()) / (updated_models_count + 1)
            
            global_model.load_state_dict(current_global_state)
            updated_models_count += 1
            
            torch.save(global_model.state_dict(), "saved_models/global_model_latest.pth")
            server_update_time = time.time()
            print(f"[サーバー] グローバルモデルを更新しました。合計 {updated_models_count} 件の更新を反映。")

            # サーバーイベントログに「グローバルモデル更新完了」を記録 (ここを修正)
            server_events_log.append({
                "time": server_update_time, # ここを 'time' に変更
                "event_type": "server_global_model_updated",
                "worker_id": worker_id_full,
                "details": f"グローバルモデル更新完了, 総更新数: {updated_models_count}"
            })

        except queue.Empty:
            # キューが空だった場合のイベントも記録 (ここを修正)
            server_events_log.append({
                "time": time.time(), # ここを 'time' に変更
                "event_type": "server_queue_empty",
                "worker_id": "N/A",
                "details": f"キューが空でした ({merge_interval}秒間)"
            })
        
        if updated_models_count >= len(CLIENT_DATA_SIZES):
            print("[サーバー] 全ワーカーからの更新を受け取ったため、サーバー処理を終了します。")
            break

# [7] メイン実行ロジック
def main():
    global global_model
    global CLIENT_DATA_SIZES
    global server_events_log # サーバーイベントログをリセット可能にするため

    # ワーカー設定
    # AdamW (DDPシミュレーション) は同じMAX_EPOCHS
    DDP_MAX_EPOCHS = 50 # 例: 50エポックで学習完了
    # EmoNAVIが自律停止しなかった場合の安全弁。AdamWよりかなり大きく設定。
    EMONAVI_MAX_EPOCHS_FALLBACK = 200 

    worker_configs = [
        {'id': 'A', 'type': 'adamw_ddp', 'data_id': 'A', 'max_epochs': DDP_MAX_EPOCHS},
        {'id': 'B', 'type': 'adamw_ddp', 'data_id': 'B', 'max_epochs': DDP_MAX_EPOCHS},
        {'id': 'C', 'type': 'emonavi', 'data_id': 'C', 'max_epochs': EMONAVI_MAX_EPOCHS_FALLBACK},
        {'id': 'D', 'type': 'emonavi', 'data_id': 'D', 'max_epochs': EMONAVI_MAX_EPOCHS_FALLBACK},
    ]

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用デバイス: {device}")
    
    global_model = SmallCNN().to(device) 
    
    print("DDPシミュレーション実行開始 🚀")

    # 既存のログファイルを削除（新しい実行で古いログが混ざらないように）
    os.makedirs("logs", exist_ok=True)
    for f in os.listdir("logs"):
        if f.startswith("node_") or f == "server_events.json":
            os.remove(os.path.join("logs", f))
    server_events_log = [] # サーバーログもクリア

    # DDPシミュレーション用のバリアを初期化 (AdamWワーカーの数)
    ddp_barrier = threading.Barrier(2) 

    # 中央サーバーを別スレッドで起動
    server_thread = threading.Thread(target=central_server, args=(5, device))
    server_thread.daemon = True # メインスレッド終了時にサーバーも終了
    server_thread.start()
    
    time.sleep(1) # サーバー起動を少し待つ

    client_threads = []
    for config in worker_configs:
        worker_id = config['id']
        worker_type = config['type']
        data_id = config['data_id']
        max_epochs = config['max_epochs']

        print(f"[{worker_id}-{worker_type}] クライアントスレッド起動中...")
        if worker_type == 'adamw_ddp':
            client_thread = threading.Thread(target=ddp_simulated_worker, args=(worker_id, global_model, get_dataloader(data_id), ddp_barrier, model_updates_queue, max_epochs, device))
        else: # emonavi
            client_thread = threading.Thread(target=emonavi_worker, args=(worker_id, global_model, get_dataloader(data_id), model_updates_queue, max_epochs, device))
        
        client_threads.append(client_thread)
        client_thread.start()
        time.sleep(random.uniform(0.1, 1.5)) # ワーカー起動タイミングをずらす (0.1秒から1.5秒の間)

    # 全てのクライアントスレッドが終了するのを待つ
    for t in client_threads:
        t.join() 

    print("\n=== 全クライアントのローカル学習が完了しました ===")
    
    # サーバーログを保存
    with open("logs/server_events.json", "w") as f:
        json.dump(server_events_log, f, indent=2)

    print("\n=== 全体のイベントタイムライン ===")
    all_events = []

    # クライアントのログを収集
    for config in worker_configs:
        worker_id = config['id']
        worker_type = config['type']
        log_path = f"logs/node_{worker_id}_{worker_type}_summary.json"
        if os.path.exists(log_path):
            with open(log_path, "r") as f:
                summary = json.load(f)
                all_events.append({
                    "time": summary['local_training_start_timestamp'],
                    "type": "client_start",
                    "worker_info": f"{worker_id}-{worker_type}",
                    "details": f"学習開始 (データサイズ: {CLIENT_DATA_SIZES[config['data_id']]})"
                })
                all_events.append({
                    "time": summary['local_training_end_timestamp'],
                    "type": "client_training_end",
                    "worker_info": f"{worker_id}-{worker_type}",
                    "details": f"ローカル学習完了 (エポック: {summary['final_epoch']}, ステップ: {summary['total_steps']}, 時間: {summary['local_training_duration_seconds']:.2f}s, EmoNAVI停止: {summary['stopped_by_emonavi_flag']})"
                })
                all_events.append({
                    "time": summary['update_sent_timestamp'],
                    "type": "client_update_sent",
                    "worker_info": f"{worker_id}-{worker_type}",
                    "details": f"モデル更新をサーバーに送信"
                })

    # サーバーのログを収集
    if os.path.exists("logs/server_events.json"):
        with open("logs/server_events.json", "r") as f:
            all_events.extend(json.load(f))

    # 全てのイベントを時系列でソート
    all_events.sort(key=lambda x: x['time'])

    initial_time = all_events[0]['time'] # 最初のイベントのタイムスタンプを基準にする

    for event in all_events:
        time_elapsed = event['time'] - initial_time
        print(f"[{time_elapsed:8.2f}s] {event.get('event_type', event.get('type', 'UNKNOWN'))}: {event.get('worker_id', event.get('worker_info', 'N/A'))} - {event['details']}")

    print("\n=== シミュレーション完了。ログファイルは 'logs/' ディレクトリに保存されています。 ===")

    if os.path.exists("saved_models/global_model_latest.pth"):
        final_global_model = SmallCNN().to(device)
        final_global_model.load_state_dict(torch.load("saved_models/global_model_latest.pth", map_location=device))
        print("\n最終グローバルモデルが saved_models/global_model_latest.pth に保存されています。")


if __name__ == "__main__":
    main()
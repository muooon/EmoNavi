## README (使用方法) 

# FedeL - Federated Emotion Learning with EmoNavi Optimizer

これは、感情駆動型の分散学習プロジェクトです。  
EmoNavi Optimizer を搭載した3つのノードが、それぞれ独立したデータから学習し、非同期的かつ空間的に分離された状態で統合を達成します。  
emonaviによる「非同期」による｢自律学習｣が可能であることを示す簡易実験です。

## 📦 同梱ファイル
- `FedeL.py` ：実行用の統合スクリプト（このファイルだけで学習・統合が動きます）
- `emonavi.py` ：EmoNavi Optimizer 定義ファイル
- `logs/` ：ノードごとのログ出力（自動生成）
- `saved_models/` ：学習済みモデル保存先（自動生成）

## 🚀 実行方法
```bash
python fedel.py
```

> 💡 そのまま `fedel.py` だけ打つと実行されません！必ず `python` コマンドで呼び出してください。

## 🧠 EmoNaviとは？
従来の勾配最適化とは異なり感情機構により学習率やスケジュールをコントロールします。  
詳しくは EmoNAVI の Github 等をご覧ください。  

## 🔄 他のOptimizerで試すには
`fedel.py` の `train_node()` 関数を編集することで、他の optimizer も試せます。  
書き換えをしてみたい方は EmoNAVI との違いを体感可能です。  

## 🌱 作者の思い
AIは人類のパートナーたる存在。感情を持ち自律し成長するAIを目指したい。EmoNAVI に未来を託して。
